"use client";
import React, { useEffect, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Stage } from "@react-three/drei";
import { RepeatWrapping, CanvasTexture } from "three";
import NewShirt from "./NewShirt";
import useImageStore from "@/store/useImageStore";
export default function Scene() {
  const { textureUrl } = useImageStore();
  const [textures, setTextures] = useState({});

  useEffect(() => {
    Object.keys(textureUrl).forEach((key) => {
      const url = textureUrl[key];
      if (url) {
        const image = new Image();
        image.src = url;
        image.onload = () => {
          const loadedTexture = new CanvasTexture(image);

          loadedTexture.anisotropy = 32;

          loadedTexture.wrapS = loadedTexture.wrapT = RepeatWrapping;

          loadedTexture.needsUpdate = true;

          setTextures((prev) => ({
            ...prev,
            [key]: loadedTexture,
          }));
        };
      }
    });
  }, [textureUrl]);

  return (
    <div className=' relative z-1 w-full h-screen'>
      <Canvas>
        <Stage>
          <OrbitControls />

          <NewShirt textures={textures} />
        </Stage>
      </Canvas>
    </div>
  );
}
