import { cn } from "@/lib/utils";
import React from "react";

export default function CustomButton({ onClick, text, icon, className }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        " leading-[100%] font-helvetica-button gap-1.5 mt-4 cursor-pointer p-2.5 flex items-center text-black text-[14px] rounded-md border-black border-[1.5px] font-bold",
        className
      )}
    >
      <span className="font-bold uppercase">{text}</span>
      {icon}
    </button>
  );
}
