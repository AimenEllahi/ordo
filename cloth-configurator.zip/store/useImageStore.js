import { create } from "zustand";

const useImageStore = create((set) => ({
  uploadedImage: null,
  textureUrl: {},
  setTextureUrl: (areaKey, dataURL) =>
    set((state) => ({
      textureUrl: {
        ...state.textureUrl,
        [areaKey]: dataURL, // Update the texture URL for the specific area
      },
    })),
  setUploadedImage: (image) => set({ uploadedImage: image }),
}));

export default useImageStore;
